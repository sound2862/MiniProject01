﻿namespace Miniproject1
{
    partial class login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            dataGridView4 = new DataGridView();
            dataGridView5 = new DataGridView();
            panel2 = new Panel();
            panel3 = new Panel();
            Sign_up = new Button();
            Sign_in = new Button();
            textBox_id = new TextBox();
            textBox_pwd = new TextBox();
            checkBox1 = new CheckBox();
            dataGridView3 = new DataGridView();
            dataGridView2 = new DataGridView();
            dataGridView1 = new DataGridView();
            FindID_label = new LinkLabel();
            FindPWD_label = new LinkLabel();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            LoGopictureBox1 = new PictureBox();
            CarPB1 = new PictureBox();
            timer1 = new System.Windows.Forms.Timer(components);
            CarPB2 = new PictureBox();
            CarPB3 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)LoGopictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)CarPB1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)CarPB2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)CarPB3).BeginInit();
            SuspendLayout();
            // 
            // dataGridView4
            // 
            dataGridView4.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView4.Location = new Point(-378, -252);
            dataGridView4.Name = "dataGridView4";
            dataGridView4.Size = new Size(404, 273);
            dataGridView4.TabIndex = 12;
            dataGridView4.Visible = false;
            // 
            // dataGridView5
            // 
            dataGridView5.CausesValidation = false;
            dataGridView5.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView5.Location = new Point(-624, -129);
            dataGridView5.Name = "dataGridView5";
            dataGridView5.Size = new Size(650, 150);
            dataGridView5.TabIndex = 13;
            dataGridView5.Visible = false;
            dataGridView5.CellContentClick += dataGridView5_CellContentClick;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Black;
            panel2.Location = new Point(94, 456);
            panel2.Name = "panel2";
            panel2.Size = new Size(210, 1);
            panel2.TabIndex = 0;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Black;
            panel3.Location = new Point(94, 502);
            panel3.Name = "panel3";
            panel3.Size = new Size(210, 1);
            panel3.TabIndex = 1;
            // 
            // Sign_up
            // 
            Sign_up.BackColor = Color.Black;
            Sign_up.Font = new Font("맑은 고딕", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 129);
            Sign_up.ForeColor = Color.White;
            Sign_up.Location = new Point(72, 520);
            Sign_up.Name = "Sign_up";
            Sign_up.Size = new Size(98, 36);
            Sign_up.TabIndex = 4;
            Sign_up.Text = "Sign Up";
            Sign_up.UseVisualStyleBackColor = false;
            Sign_up.Click += Sign_up_Click;
            // 
            // Sign_in
            // 
            Sign_in.BackColor = Color.Black;
            Sign_in.Font = new Font("맑은 고딕", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 129);
            Sign_in.ForeColor = Color.White;
            Sign_in.Location = new Point(213, 520);
            Sign_in.Name = "Sign_in";
            Sign_in.Size = new Size(98, 36);
            Sign_in.TabIndex = 5;
            Sign_in.Text = "Sign In";
            Sign_in.UseVisualStyleBackColor = false;
            Sign_in.Click += Sign_in_Click;
            // 
            // textBox_id
            // 
            textBox_id.BackColor = Color.White;
            textBox_id.BorderStyle = BorderStyle.None;
            textBox_id.Font = new Font("맑은 고딕", 12F);
            textBox_id.Location = new Point(95, 432);
            textBox_id.Name = "textBox_id";
            textBox_id.Size = new Size(210, 22);
            textBox_id.TabIndex = 6;
            // 
            // textBox_pwd
            // 
            textBox_pwd.BorderStyle = BorderStyle.None;
            textBox_pwd.Font = new Font("맑은 고딕", 12F);
            textBox_pwd.Location = new Point(95, 478);
            textBox_pwd.Name = "textBox_pwd";
            textBox_pwd.Size = new Size(210, 22);
            textBox_pwd.TabIndex = 7;
            textBox_pwd.TextChanged += textBox2_TextChanged;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Font = new Font("맑은 고딕", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 129);
            checkBox1.Location = new Point(317, 537);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(68, 21);
            checkBox1.TabIndex = 8;
            checkBox1.Text = "Admin";
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // dataGridView3
            // 
            dataGridView3.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView3.Location = new Point(-378, -243);
            dataGridView3.Name = "dataGridView3";
            dataGridView3.Size = new Size(404, 264);
            dataGridView3.TabIndex = 11;
            dataGridView3.Visible = false;
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(-413, -261);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.Size = new Size(439, 282);
            dataGridView2.TabIndex = 10;
            dataGridView2.Visible = false;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(-413, -243);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(439, 264);
            dataGridView1.TabIndex = 9;
            dataGridView1.Visible = false;
            // 
            // FindID_label
            // 
            FindID_label.AutoSize = true;
            FindID_label.Location = new Point(262, 577);
            FindID_label.Name = "FindID_label";
            FindID_label.Size = new Size(43, 15);
            FindID_label.TabIndex = 14;
            FindID_label.TabStop = true;
            FindID_label.Text = "아이디";
            FindID_label.LinkClicked += FindID_label_LinkClicked;
            // 
            // FindPWD_label
            // 
            FindPWD_label.AutoSize = true;
            FindPWD_label.Location = new Point(317, 577);
            FindPWD_label.Name = "FindPWD_label";
            FindPWD_label.Size = new Size(83, 15);
            FindPWD_label.TabIndex = 15;
            FindPWD_label.TabStop = true;
            FindPWD_label.Text = "비밀번호 찾기";
            FindPWD_label.LinkClicked += FindPWD_label_LinkClicked;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = SFMiniProject.Properties.Resources.ID;
            pictureBox2.Location = new Point(47, 418);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(41, 39);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 16;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = SFMiniProject.Properties.Resources.Password;
            pictureBox3.Location = new Point(47, 463);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(41, 39);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 17;
            pictureBox3.TabStop = false;
            // 
            // LoGopictureBox1
            // 
            LoGopictureBox1.Image = SFMiniProject.Properties.Resources.KiaLoGo;
            LoGopictureBox1.Location = new Point(72, 12);
            LoGopictureBox1.Name = "LoGopictureBox1";
            LoGopictureBox1.Size = new Size(251, 123);
            LoGopictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            LoGopictureBox1.TabIndex = 18;
            LoGopictureBox1.TabStop = false;
            // 
            // CarPB1
            // 
            CarPB1.Location = new Point(35, 141);
            CarPB1.Name = "CarPB1";
            CarPB1.Size = new Size(313, 239);
            CarPB1.SizeMode = PictureBoxSizeMode.StretchImage;
            CarPB1.TabIndex = 19;
            CarPB1.TabStop = false;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // CarPB2
            // 
            CarPB2.Location = new Point(35, 141);
            CarPB2.Name = "CarPB2";
            CarPB2.Size = new Size(313, 239);
            CarPB2.SizeMode = PictureBoxSizeMode.StretchImage;
            CarPB2.TabIndex = 20;
            CarPB2.TabStop = false;
            // 
            // CarPB3
            // 
            CarPB3.Location = new Point(35, 141);
            CarPB3.Name = "CarPB3";
            CarPB3.Size = new Size(313, 239);
            CarPB3.SizeMode = PictureBoxSizeMode.StretchImage;
            CarPB3.TabIndex = 21;
            CarPB3.TabStop = false;
            // 
            // login
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(403, 601);
            Controls.Add(CarPB3);
            Controls.Add(CarPB2);
            Controls.Add(CarPB1);
            Controls.Add(LoGopictureBox1);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(FindID_label);
            Controls.Add(FindPWD_label);
            Controls.Add(dataGridView5);
            Controls.Add(dataGridView4);
            Controls.Add(checkBox1);
            Controls.Add(textBox_pwd);
            Controls.Add(dataGridView3);
            Controls.Add(textBox_id);
            Controls.Add(Sign_in);
            Controls.Add(dataGridView2);
            Controls.Add(Sign_up);
            Controls.Add(dataGridView1);
            Controls.Add(panel3);
            Controls.Add(panel2);
            MdiChildrenMinimizedAnchorBottom = false;
            Name = "login";
            Text = "로그인 화면";
            Load += login_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView4).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView5).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)LoGopictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)CarPB1).EndInit();
            ((System.ComponentModel.ISupportInitialize)CarPB2).EndInit();
            ((System.ComponentModel.ISupportInitialize)CarPB3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Panel panel2;
        private Panel panel3;
        private Button Sign_up;
        private Button Sign_in;
        private TextBox textBox_id;
        private TextBox textBox_pwd;
        private CheckBox checkBox1;
        private DataGridView dataGridView5;
        private DataGridView dataGridView4;
        private DataGridView dataGridView3;
        private DataGridView dataGridView2;
        private DataGridView dataGridView1;
        private LinkLabel FindID_label;
        private LinkLabel FindPWD_label;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox LoGopictureBox1;
        private PictureBox CarPB1;
        private System.Windows.Forms.Timer timer1;
        private PictureBox CarPB2;
        private PictureBox CarPB3;
    }
}