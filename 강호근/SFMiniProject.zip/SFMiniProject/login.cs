﻿using Oracle.ManagedDataAccess.Client;
using System.Data;
using System.Windows.Forms;

namespace Miniproject1
{
    public partial class login : Form
    {
        private DatabaseUtil Util = new DatabaseUtil();
        private int imageIndex = 0;
        private System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer(); // 네임스페이스를 명시적으로 지정
        private int slideSpeed = 3; // 슬라이드 속도
        private int totalImages = 6; // 슬라이드할 이미지의 총 개수
        private string[] imageFiles;

        public login()
        {
            InitializeComponent();

            // 이미지 파일 배열 설정
            imageFiles = new string[]
            {
                System.Environment.CurrentDirectory + "/The2024K9.png",
                System.Environment.CurrentDirectory + "/ThenewK5.png",
                System.Environment.CurrentDirectory + "/ThenewK8.png",
                System.Environment.CurrentDirectory + "/Carnival.png",
                System.Environment.CurrentDirectory + "/TheKiaEV3.png",
                System.Environment.CurrentDirectory + "/ThenewEV6.png"
            };

            // Timer 설정
            timer.Interval = 50; // 타이머 간격 (ms)
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void login_Load(object sender, EventArgs e)
        {
            CarPB1.Image = Image.FromFile(imageFiles[0]);
            CarPB2.Image = Image.FromFile(imageFiles[1]);
            CarPB3.Image = Image.FromFile(imageFiles[2]);

            // 초기 위치 설정
            CarPB1.Left = 0;
            CarPB2.Left = CarPB1.Width;
            CarPB3.Left = CarPB2.Left + CarPB2.Width;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            // 세 PictureBox를 왼쪽으로 이동
            CarPB1.Left -= slideSpeed;
            CarPB2.Left -= slideSpeed;
            CarPB3.Left -= slideSpeed;

            // 첫 번째 PictureBox가 화면 밖으로 나갔을 때
            if (CarPB1.Left <= -CarPB1.Width)
            {
                CarPB1.Left = CarPB3.Left + CarPB3.Width; // 첫 번째 PictureBox를 세 번째 뒤로 이동
                imageIndex = (imageIndex + 1) % totalImages;
                CarPB1.Image = Image.FromFile(imageFiles[imageIndex]); // 다음 이미지로 교체
            }

            // 두 번째 PictureBox가 화면 밖으로 나갔을 때
            if (CarPB2.Left <= -CarPB2.Width)
            {
                CarPB2.Left = CarPB1.Left + CarPB1.Width; // 두 번째 PictureBox를 첫 번째 뒤로 이동
                imageIndex = (imageIndex + 1) % totalImages;
                CarPB2.Image = Image.FromFile(imageFiles[imageIndex]); // 다음 이미지로 교체
            }

            // 세 번째 PictureBox가 화면 밖으로 나갔을 때
            if (CarPB3.Left <= -CarPB3.Width)
            {
                CarPB3.Left = CarPB2.Left + CarPB2.Width; // 세 번째 PictureBox를 두 번째 뒤로 이동
                imageIndex = (imageIndex + 1) % totalImages;
                CarPB3.Image = Image.FromFile(imageFiles[imageIndex]); // 다음 이미지로 교체
            }
        }

        private void Sign_up_Click(object sender, EventArgs e)
        {
            Sign_Up signUpForm = new Sign_Up();
            signUpForm.Show();
        }

        private void Sign_in_Click(object sender, EventArgs e)
        {
            bool loginSuccess = false;
            bool isAdmin = false;

            dataGridView5.DataSource = Util.GetTableData("LoginTable");

            foreach (DataGridViewRow row in dataGridView5.Rows)
            {
                if (row.Cells[2].Value != null && row.Cells[3].Value != null && row.Cells[4].Value != null)
                {
                    string id = row.Cells[2].Value.ToString();
                    string password = row.Cells[3].Value.ToString();
                    string admin = row.Cells[4].Value.ToString();

                    if (textBox_id.Text == id && textBox_pwd.Text == password)
                    {
                        loginSuccess = true;
                        isAdmin = admin == "1";
                        break;
                    }
                }
            }

            if (loginSuccess)
            {
                if (isAdmin && checkBox1.Checked)
                {
                    MessageBox.Show("관리자 로그인!");
                }
                else
                {
                    MessageBox.Show("사용자 로그인 성공");
                }
            }
            else
            {
                MessageBox.Show("로그인 실패");
            }
        }

        private void dataGridView5_CellContentClick(object sender, DataGridViewCellEventArgs e) { }

        private void checkBox1_CheckedChanged(object sender, EventArgs e) { }

        private void textBox2_TextChanged(object sender, EventArgs e) { }

        private void FindID_label_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Sign_Up_FIndID FIndIDForm = new Sign_Up_FIndID();
            FIndIDForm.Show();
        }

        private void FindPWD_label_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Sign_Up_FIndPWD FIndPWDForm = new Sign_Up_FIndPWD();
            FIndPWDForm.Show();
        }

        private void button1_Click(object sender, EventArgs e) { }

        private void pictureBox1_Click(object sender, EventArgs e) { }

        private void timer1_Tick(object sender, EventArgs e) { }

        private void button1_Click_1(object sender, EventArgs e) { }
    }
}

class DatabaseUtil
{
    private string strConn = "Data Source=(DESCRIPTION=" +
                             "(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)" +
                             "(HOST=localhost)(PORT=1521)))" +
                             "(CONNECT_DATA=(SERVER=DEDICATED)" +
                             "(SERVICE_NAME=xe)));" +
                             "User Id=scott;Password=TIGER;";

    public DataTable GetTableData(string tableName)
    {
        using (OracleConnection conn = new OracleConnection(strConn))
        {
            string query = $"SELECT * FROM {tableName}";
            OracleDataAdapter adapter = new OracleDataAdapter(query, conn);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);
            return dataTable;
        }
    }

    public string GetCellValue(DataGridView dgv, int rowIndex, int columnIndex)
    {
        int adjustedRowIndex = rowIndex - 1;
        int adjustedColumnIndex = columnIndex - 1;

        if (adjustedRowIndex >= 0 && adjustedRowIndex < dgv.Rows.Count &&
            adjustedColumnIndex >= 0 && adjustedColumnIndex < dgv.Columns.Count)
        {
            return dgv.Rows[adjustedRowIndex].Cells[adjustedColumnIndex].Value.ToString();
        }
        else
        {
            return "Invalid index";
        }
    }

    public void ExecuteNonQuery(string commandText)
    {
        using (OracleConnection conn = new OracleConnection(strConn))
        {
            using (OracleCommand cmd = new OracleCommand(commandText, conn))
            {
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }

    public void dgvUpdate(DataGridView dgv, string table)
    {
        dgv.DataSource = GetTableData(table);
    }
}
