﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Miniproject1
{
    public partial class Admin : Form
    {
        private DatabaseUtil Util = new DatabaseUtil();
        private DesignUtil DsUtil = new DesignUtil();
        string connectionString = "";

        public Admin()
        {
            InitializeComponent();
        }

        private void Admin_Load(object sender, EventArgs e)
        {
            try
            {
                // 연결 문자열 초기화
                connectionString = Util.Conneting();

                // 초기 설정 시 콤보 박스에 차트 종류를 추가
                comboBoxChartType.Items.Clear();
                comboBoxChartType.Items.Add("월간 총 판매량");
                comboBoxChartType.Items.Add("월간 차종별 판매량");
                comboBoxChartType.Items.Add("월간 연령대별 판매량");

                comboBoxChartType.Visible = false;
                chartDisplay.Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("초기화 중 오류가 발생했습니다: " + ex.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Search_btn_Click(object sender, EventArgs e)
        {
            using (OracleConnection conn = new OracleConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    string query = @"SELECT 
                                        CustomerID AS ""CUSTOMERID"",
                                        Model AS ""MODEL"",
                                        Engine AS ""ENGINE"",
                                        Color AS ""COLOR"",
                                        Options AS ""OPTIONS"",
                                        Id AS ""ID"",
                                        OrderDay AS ""ORDERDAY""
                                     FROM Customer";

                    OracleDataAdapter adapter = new OracleDataAdapter(query, conn);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dgv_Order.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("데이터를 불러오는 중 오류가 발생했습니다: " + ex.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            DsUtil.ChangePanel(panel1, dgv_Order);
        }

        private void Production_btn_Click(object sender, EventArgs e)
        {
            //공정 가기
        }

        private void Live_btn_Click(object sender, EventArgs e)
        {
            //공정 보기
        }

        private void Chart_btn_Click(object sender, EventArgs e)
        {
            // 차트와 콤보박스를 표시
            DsUtil.ChangePanel(panel1, chartDisplay);
            chartDisplay.Visible = true;
            comboBoxChartType.Visible = true;
            comboBoxChartType.BringToFront();
        }

        private void Exit_btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBoxChartType_SelectedIndexChanged(object sender, EventArgs e)
        {
            chartDisplay.Series.Clear();  // 기존 차트 데이터를 지움

            // 선택된 항목에 따라 DB에서 데이터를 가져와 차트로 표시
            string selectedOption = comboBoxChartType.SelectedItem.ToString();

            switch (selectedOption)
            {
                case "월간 총 판매량":
                    LoadTotalSalesData();
                    break;
                case "월간 차종별 판매량":
                    LoadModelSalesData();
                    break;
                case "월간 연령대별 판매량":
                    LoadAgeGroupSalesData();
                    break;
            }
        }

        private void LoadTotalSalesData()
        {
            using (OracleConnection conn = new OracleConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    string query = @"SELECT TO_CHAR(OrderDay, 'MM') AS MONTH, COUNT(*) AS TOTAL_SALES
                                     FROM Customer
                                     GROUP BY TO_CHAR(OrderDay, 'MM')
                                     ORDER BY MONTH";

                    OracleDataAdapter adapter = new OracleDataAdapter(query, conn);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    // 차트 영역과 시리즈 초기화
                    InitializeChart();

                    Series series = new Series("총 판매량");
                    series.ChartType = SeriesChartType.Column;

                    foreach (DataRow row in dataTable.Rows)
                    {
                        series.Points.AddXY(row["MONTH"].ToString(), Convert.ToInt32(row["TOTAL_SALES"]));
                    }

                    chartDisplay.Series.Add(series);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("데이터를 불러오는 중 오류가 발생했습니다: " + ex.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void LoadModelSalesData()
        {
            using (OracleConnection conn = new OracleConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    string query = @"SELECT TO_CHAR(OrderDay, 'MM') AS MONTH, Model, COUNT(*) AS MODEL_SALES
                                     FROM Customer
                                     GROUP BY TO_CHAR(OrderDay, 'MM'), Model
                                     ORDER BY MONTH, Model";

                    OracleDataAdapter adapter = new OracleDataAdapter(query, conn);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    // 차트 영역과 시리즈 초기화
                    InitializeChart();

                    foreach (string model in new string[] { "K3", "K5", "K8" })
                    {
                        Series series = new Series(model);
                        series.ChartType = SeriesChartType.Column;

                        DataRow[] rows = dataTable.Select($"Model = '{model}'");

                        foreach (DataRow row in rows)
                        {
                            series.Points.AddXY(row["MONTH"].ToString(), Convert.ToInt32(row["MODEL_SALES"]));
                        }

                        chartDisplay.Series.Add(series);
                    }

                    // 범례 추가
                    chartDisplay.Legends.Add(new Legend("차종별 판매량"));
                }
                catch (Exception ex)
                {
                    MessageBox.Show("데이터를 불러오는 중 오류가 발생했습니다: " + ex.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void LoadAgeGroupSalesData()
        {
            using (OracleConnection conn = new OracleConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    string query = @"SELECT TO_CHAR(c.OrderDay, 'MM') AS MONTH,
                                    CASE
                                        WHEN EXTRACT(YEAR FROM SYSDATE) - TO_NUMBER('19' || SUBSTR(l.Birthday, 1, 2)) BETWEEN 20 AND 29 THEN '20대'
                                        WHEN EXTRACT(YEAR FROM SYSDATE) - TO_NUMBER('19' || SUBSTR(l.Birthday, 1, 2)) BETWEEN 30 AND 39 THEN '30대'
                                        WHEN EXTRACT(YEAR FROM SYSDATE) - TO_NUMBER('19' || SUBSTR(l.Birthday, 1, 2)) BETWEEN 40 AND 49 THEN '40대'
                                        ELSE '50대 이상'
                                    END AS AGE_GROUP,
                                    COUNT(*) AS AGE_GROUP_SALES
                             FROM Customer c
                             JOIN LoginTable l ON c.Id = l.Id
                             GROUP BY TO_CHAR(c.OrderDay, 'MM'),
                                      CASE
                                          WHEN EXTRACT(YEAR FROM SYSDATE) - TO_NUMBER('19' || SUBSTR(l.Birthday, 1, 2)) BETWEEN 20 AND 29 THEN '20대'
                                          WHEN EXTRACT(YEAR FROM SYSDATE) - TO_NUMBER('19' || SUBSTR(l.Birthday, 1, 2)) BETWEEN 30 AND 39 THEN '30대'
                                          WHEN EXTRACT(YEAR FROM SYSDATE) - TO_NUMBER('19' || SUBSTR(l.Birthday, 1, 2)) BETWEEN 40 AND 49 THEN '40대'
                                          ELSE '50대 이상'
                                      END
                             ORDER BY MONTH, AGE_GROUP";

                    OracleDataAdapter adapter = new OracleDataAdapter(query, conn);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    // 차트 영역과 시리즈 초기화
                    InitializeChart();

                    foreach (string ageGroup in new string[] { "20대", "30대", "40대", "50대 이상" })
                    {
                        Series series = new Series(ageGroup);
                        series.ChartType = SeriesChartType.Column;

                        DataRow[] rows = dataTable.Select($"AGE_GROUP = '{ageGroup}'");

                        foreach (DataRow row in rows)
                        {
                            series.Points.AddXY(row["MONTH"].ToString(), Convert.ToInt32(row["AGE_GROUP_SALES"]));
                        }

                        chartDisplay.Series.Add(series);
                    }

                    // 범례 추가
                    chartDisplay.Legends.Add(new Legend("연령대별 판매량"));
                }
                catch (Exception ex)
                {
                    MessageBox.Show("데이터를 불러오는 중 오류가 발생했습니다: " + ex.Message, "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void InitializeChart()
        {
            // 차트 초기화
            chartDisplay.Series.Clear();
            chartDisplay.ChartAreas.Clear();

            ChartArea chartArea = new ChartArea("Default");
            chartDisplay.ChartAreas.Add(chartArea);
            chartDisplay.Legends.Clear(); // 범례 제거
        }
    }
}