﻿namespace Miniproject1
{
    public partial class Sign_Up : System.Windows.Forms.Form
    {
        private DatabaseUtil Util = new DatabaseUtil();

        public Sign_Up()
        {
            InitializeComponent();
        }


        private void Sign_Up_Load(object sender, EventArgs e)
        {
            Util.dgvUpdate(dataGridView5, "LoginTable");
        }

        private void Sign_up_btn_Click(object sender, EventArgs e)
        {
            string sqlCommand = $"INSERT INTO loginTable (ID, USER_NAME, USER_ID, USER_PWD, ADMIN, Birthday) " +
                                $"VALUES (logintable_seq.nextval, '{textBox_name.Text}', '{textBox_id.Text}', '{textBox_pwd.Text}', 0, '{textBox_birth.Text}')";

            try
            {
                Util.ExecuteNonQuery(sqlCommand);
                Util.dgvUpdate(dataGridView5, "LoginTable");

                this.Close();
                MessageBox.Show("회원가입이 완료되었습니다.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("빈칸을 모두 채워주세요");
            }
        }

        

        //////
        //실수
        private void label4_Click(object sender, EventArgs e)
        {

        }
        private void textBox_name_TextChanged(object sender, EventArgs e)
        {

        }
        private void dataGridView5_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

    }
}
