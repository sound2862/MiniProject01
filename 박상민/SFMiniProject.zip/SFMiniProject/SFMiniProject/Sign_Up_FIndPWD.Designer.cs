﻿namespace Miniproject1
{
    partial class Sign_Up_FIndPWD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox_birth = new TextBox();
            label5 = new Label();
            panel4 = new Panel();
            Sign_up_btn = new Button();
            textBox_name = new TextBox();
            label3 = new Label();
            panel1 = new Panel();
            dataGridView5 = new DataGridView();
            textBox_ID = new TextBox();
            label1 = new Label();
            panel2 = new Panel();
            ((System.ComponentModel.ISupportInitialize)dataGridView5).BeginInit();
            SuspendLayout();
            // 
            // textBox_birth
            // 
            textBox_birth.BackColor = Color.White;
            textBox_birth.BorderStyle = BorderStyle.None;
            textBox_birth.Location = new Point(66, 49);
            textBox_birth.Name = "textBox_birth";
            textBox_birth.Size = new Size(210, 16);
            textBox_birth.TabIndex = 35;
            textBox_birth.TextChanged += textBox_birth_TextChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("맑은 고딕", 9F, FontStyle.Bold, GraphicsUnit.Point, 129);
            label5.Location = new Point(25, 49);
            label5.Name = "label5";
            label5.Size = new Size(35, 15);
            label5.TabIndex = 34;
            label5.Text = "Birth";
            // 
            // panel4
            // 
            panel4.BackColor = Color.Black;
            panel4.Location = new Point(66, 67);
            panel4.Name = "panel4";
            panel4.Size = new Size(210, 1);
            panel4.TabIndex = 33;
            // 
            // Sign_up_btn
            // 
            Sign_up_btn.Font = new Font("맑은 고딕", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 129);
            Sign_up_btn.Location = new Point(100, 163);
            Sign_up_btn.Name = "Sign_up_btn";
            Sign_up_btn.Size = new Size(108, 46);
            Sign_up_btn.TabIndex = 32;
            Sign_up_btn.Text = "찾기";
            Sign_up_btn.UseVisualStyleBackColor = true;
            Sign_up_btn.Click += Sign_up_btn_Click;
            // 
            // textBox_name
            // 
            textBox_name.BackColor = Color.White;
            textBox_name.BorderStyle = BorderStyle.None;
            textBox_name.Location = new Point(66, 88);
            textBox_name.Name = "textBox_name";
            textBox_name.Size = new Size(210, 16);
            textBox_name.TabIndex = 31;
            textBox_name.TextChanged += textBox_name_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("맑은 고딕", 9F, FontStyle.Bold, GraphicsUnit.Point, 129);
            label3.Location = new Point(18, 88);
            label3.Name = "label3";
            label3.Size = new Size(42, 15);
            label3.TabIndex = 30;
            label3.Text = "Name";
            // 
            // panel1
            // 
            panel1.BackColor = Color.Black;
            panel1.Location = new Point(66, 106);
            panel1.Name = "panel1";
            panel1.Size = new Size(210, 1);
            panel1.TabIndex = 29;
            // 
            // dataGridView5
            // 
            dataGridView5.CausesValidation = false;
            dataGridView5.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView5.Location = new Point(-596, -113);
            dataGridView5.Name = "dataGridView5";
            dataGridView5.Size = new Size(650, 150);
            dataGridView5.TabIndex = 36;
            dataGridView5.Visible = false;
            // 
            // textBox_ID
            // 
            textBox_ID.BackColor = Color.White;
            textBox_ID.BorderStyle = BorderStyle.None;
            textBox_ID.Location = new Point(66, 126);
            textBox_ID.Name = "textBox_ID";
            textBox_ID.Size = new Size(210, 16);
            textBox_ID.TabIndex = 39;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("맑은 고딕", 9F, FontStyle.Bold, GraphicsUnit.Point, 129);
            label1.Location = new Point(40, 126);
            label1.Name = "label1";
            label1.Size = new Size(20, 15);
            label1.TabIndex = 38;
            label1.Text = "ID";
            // 
            // panel2
            // 
            panel2.BackColor = Color.Black;
            panel2.Location = new Point(66, 144);
            panel2.Name = "panel2";
            panel2.Size = new Size(210, 1);
            panel2.TabIndex = 37;
            // 
            // Sign_Up_FIndPWD
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(334, 245);
            Controls.Add(textBox_ID);
            Controls.Add(label1);
            Controls.Add(panel2);
            Controls.Add(dataGridView5);
            Controls.Add(textBox_birth);
            Controls.Add(label5);
            Controls.Add(panel4);
            Controls.Add(Sign_up_btn);
            Controls.Add(textBox_name);
            Controls.Add(label3);
            Controls.Add(panel1);
            Name = "Sign_Up_FIndPWD";
            Text = "Sign_Up_FIndPWD";
            Load += Sign_Up_FIndPWD_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView5).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox_birth;
        private Label label5;
        private Panel panel4;
        private Button Sign_up_btn;
        private TextBox textBox_name;
        private Label label3;
        private Panel panel1;
        private DataGridView dataGridView5;
        private TextBox textBox_ID;
        private Label label1;
        private Panel panel2;
    }
}