using Oracle.ManagedDataAccess.Client;
using System.Data;
using System.Windows.Forms.DataVisualization.Charting;

namespace UtilProject
{
    public partial class util : Form
    {
        public util()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}

public class DatabaseUtil
{
    public string Conneting()
    {
        string strConn = "Data Source=(DESCRIPTION=" +
                             "(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)" +
                             "(HOST=localhost)(PORT=9000)))" +
                             "(CONNECT_DATA=(SERVER=DEDICATED)" +
                             "(SERVICE_NAME=xe)));" +
                             "User Id=scott;Password=tiger;";
        return strConn;
    }

    public DataTable GetTableData(string tableName)
    {
        using (OracleConnection conn = new OracleConnection(Conneting()))
        {
            string query = $"SELECT * FROM {tableName}";
            OracleDataAdapter adapter = new OracleDataAdapter(query, conn);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);
            return dataTable;
        }
    }

    public string GetCellValue(DataGridView dgv, int rowIndex, int columnIndex)
    {
        int adjustedRowIndex = rowIndex - 1;
        int adjustedColumnIndex = columnIndex - 1;

        if (adjustedRowIndex >= 0 && adjustedRowIndex < dgv.Rows.Count &&
            adjustedColumnIndex >= 0 && adjustedColumnIndex < dgv.Columns.Count)
        {
            return dgv.Rows[adjustedRowIndex].Cells[adjustedColumnIndex].Value.ToString();
        }
        else
        {
            return "Invalid index";
        }
    }

    public void ExecuteNonQuery(string commandText)
    {
        using (OracleConnection conn = new OracleConnection(Conneting()))
        {
            using (OracleCommand cmd = new OracleCommand(commandText, conn))
            {
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }

    public void dgvUpdate(DataGridView dgv, string table)
    {
        dgv.DataSource = GetTableData(table);
    }

    public string declare_Parameter(string str,string Query)
    {
        using (OracleConnection conn = new OracleConnection(Conneting()))
        {
            conn.Open();

            using (OracleCommand cmd = new OracleCommand(Query, conn))
            {
                cmd.Parameters.Add(new OracleParameter($":{str}", str));
                cmd.ExecuteNonQuery();
            }
        }

        return $":{str}";
    }

    
}
public class DesignUtil
{
    public void ChangePanel(Panel panel, Chart chart)
    {
        chart.Visible = true;
        panel.Controls.Clear();
        panel.Controls.Add(chart);
        chart.Dock = DockStyle.Fill;
    }

    public void ChangePanel(Panel panel, DataGridView dgv)
    {
        dgv.Visible = true;
        panel.Controls.Clear();
        panel.Controls.Add(dgv);
        dgv.Dock = DockStyle.Fill;
    }

    public void ChangePanel(Panel panel, ComboBox comboBox)
    {
        comboBox.Visible = true;
        panel.Controls.Clear();
        panel.Controls.Add(comboBox);
        comboBox.Dock = DockStyle.Fill;
    }
}
