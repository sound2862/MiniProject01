﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Miniproject1
{
    public partial class Admin : Form
    {
        private DatabaseUtil Util = new DatabaseUtil();
        private DesignUtil DsUtil = new DesignUtil();
        string strConn = "";
        public Admin()
        {
            InitializeComponent();
        }

        private void Admin_Load(object sender, EventArgs e)
        {
            strConn = Util.Conneting();

        }

        private void Search_btn_Click(object sender, EventArgs e)
        {
            using (OracleConnection conn = new OracleConnection(strConn))
            {
                string query = @"SELECT 
                                     CustomerID AS ""주문번호"",
                                     Model AS ""차량종류"",
                                     Engine AS ""엔진"",
                                     Color AS ""차량색상"",
                                     Options AS ""옵션"",
                                     Id AS ""주문자"",
                                     OrderDay AS ""주문일시""
                                 FROM Customer";
                OracleDataAdapter adapter = new OracleDataAdapter(query, conn);
                DataTable dataTable = new DataTable();
                conn.Open();
                adapter.Fill(dataTable);
                dgv_Order.DataSource = dataTable;
            }
            DsUtil.ChangePanel(mainPanel, dgv_Order);
        }

        private void Production_btn_Click(object sender, EventArgs e)
        {
            //공정 가기
        }

        private void Live_btn_Click(object sender, EventArgs e)
        {
            //공정 보기
        }

        private void Chart_btn_Click(object sender, EventArgs e)
        {
            DsUtil.ChangePanel(mainPanel, chart1);
        }

        private void Exit_btn_Click(object sender, EventArgs e)
        {

        }

        //실수
        private void mainPanel_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
